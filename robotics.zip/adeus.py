print("adeus")
